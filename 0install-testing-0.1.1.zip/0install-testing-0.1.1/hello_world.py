
import sys

print("Hello from 0install!")
print("Running with Python version:", sys.version)